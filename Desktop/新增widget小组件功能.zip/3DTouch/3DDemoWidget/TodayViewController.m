//
//  TodayViewController.m
//  ATYunPayWidget
//
//  Created by aten07 on 2017/4/5.
//  Copyright © 2017年 艾腾软件. All rights reserved.
//

#import "TodayViewController.h"
#import <NotificationCenter/NotificationCenter.h>


typedef NS_ENUM(NSUInteger, WidgetFunctionType) {
    WidgetFunctionTypeScan = 3,
    WidgetFunctionTypeTransfer,
    WidgetFunctionTypeBalance,
    WidgetFunctionTypeIncrease
};


@interface TodayViewController () <NCWidgetProviding>

@end

@implementation TodayViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //设置widget展示视图的大小
    self.preferredContentSize = CGSizeMake(CGRectGetWidth([UIScreen mainScreen].bounds), 100);
    NSArray * array =@[@"扫一扫",@"转账",@"云商保",@"云增值"];
    NSArray * arrayIcon =@[@"scanIcon",@"transferIcon",@"balanceIcon",@"increaseIcon"];
    
    for (int i = 0; i < array.count; i++) {
        UIButton * btn =[UIButton buttonWithType:UIButtonTypeCustom];
        CGSize size = self.preferredContentSize;
        btn.frame = CGRectMake((size.width -30)/array.count *i + 10,25, (size.width-70)/array.count, 70);
        [btn setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@",arrayIcon[i]]] forState:UIControlStateNormal];
        [btn setTitle:array[i] forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor colorWithWhite:0.400 alpha:1.000] forState:UIControlStateNormal];
        btn.titleLabel.font =[UIFont systemFontOfSize:12];
        btn.titleLabel.textAlignment = NSTextAlignmentCenter;
        
        CGSize imageSize =  btn.imageView.frame.size;
        CGSize titleSize = btn.titleLabel.frame.size;
        
        CGFloat totalHeight = imageSize.height + titleSize.height + 10.0;
        
        btn.imageEdgeInsets = UIEdgeInsetsMake(-(totalHeight - imageSize.height), 0.0, 0.0, -titleSize.width);
        btn.titleEdgeInsets = UIEdgeInsetsMake(0, -imageSize.width, -(totalHeight - titleSize.height), 0.0);
        [btn addTarget:self action:@selector(btnClickOpenURLContainingAPP:) forControlEvents:UIControlEventTouchUpInside];
        
        btn.tag = i+3;
        [self.view addSubview:btn];
    }
    
    NSError * error = nil;
    [self.extensionContext cancelRequestWithError:error];
}

//    在NSExtensionContext中，新添了widgetLargestAvailableDisplayMode属性，来确认当前widget是展开还是折叠状态。所以，先在viewWillAppear中设置widget的mode为展开。
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    //    self.extensionContext.widgetLargestAvailableDisplayMode = NCWidgetDisplayModeExpanded;
}

//  然后，就是展开和折叠的处理了。在NCWidgetProviding协议中，新添了这么个方法widgetActiveDisplayModeDidChange，不赘述，直接用代码示例说明它的用途：
//- (void)widgetActiveDisplayModeDidChange:(NCWidgetDisplayMode)activeDisplayMode withMaximumSize:(CGSize)maxSize {
//    if (activeDisplayMode == NCWidgetDisplayModeCompact) {
//        self.preferredContentSize = CGSizeMake([UIScreen mainScreen].bounds.size.width, 110);
//    } else {
//        self.preferredContentSize = CGSizeMake([UIScreen mainScreen].bounds.size.width, 300);
//    }
//}

-(void)btnClickOpenURLContainingAPP:(UIButton *)btn
{
    NSString *strUrl;
    switch (btn.tag) {
        case WidgetFunctionTypeScan:
            strUrl = @"WidgetFunctionTypeScan";
            break;
        case WidgetFunctionTypeTransfer:
            strUrl = @"WidgetFunctionTypeTransfer";
            break;
        case WidgetFunctionTypeBalance:
            strUrl = @"WidgetFunctionTypeBalance";
            break;
        case WidgetFunctionTypeIncrease:
            strUrl = @"WidgetFunctionTypeIncrease";
            break;
    }
    
    [self.extensionContext openURL:[NSURL URLWithString:@"TodayDemo://action=GotoHomePage"]
                 completionHandler:^(BOOL success) {
                     NSLog(@"open url result:%d",success);
                 }];
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)widgetPerformUpdateWithCompletionHandler:(void (^)(NCUpdateResult))completionHandler {
    // Perform any setup necessary in order to update the view.
    
    // If an error is encountered, use NCUpdateResultFailed
    // If there's no update required, use NCUpdateResultNoData
    // If there's an update, use NCUpdateResultNewData
    
    completionHandler(NCUpdateResultNewData);
}

@end
