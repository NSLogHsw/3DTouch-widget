//
//  DMPresentationViewController.h
//  DM3DTouchDemo
//
//  Created by Damon on 2017/8/29.
//  Copyright © 2017年 damon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DMPresentationViewController : UIViewController

@property (nonatomic, strong)NSMutableArray *arrData;

@property (nonatomic, assign)NSInteger index;

@property (nonatomic, copy)NSString *strInfo;

@end
