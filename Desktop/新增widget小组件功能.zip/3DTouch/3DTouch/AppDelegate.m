//
//  AppDelegate.m
//  3DTouch
//
//  Created by Shiwen Huang on 2018/5/8.
//  Copyright © 2018年 Shiwen Huang. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    [self initShortcutItems];
    
    
    return YES;
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    dispatch_time_t delayTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC));
    dispatch_after(delayTime, dispatch_get_main_queue(), ^{
        [[NSNotificationCenter defaultCenter] postNotificationName:@"touchOrWidgetItem" object:nil];
    });
}
- (void)application:(UIApplication *)application performActionForShortcutItem:(UIApplicationShortcutItem *)shortcutItem completionHandler:(void (^)(BOOL))completionHandler {
    
    //这里可以获的shortcutItem对象的唯一标识符
    //不管APP在后台还是进程被杀死，只要通过主屏快捷操作进来的，都会调用这个方法
    [self touchStartApp:shortcutItem];

    if (completionHandler) completionHandler(YES);

}

- (void)initShortcutItems{
    if([[UIDevice currentDevice].systemVersion floatValue] < 9.0) return;
    
    //创建自定义的icon
    UIApplicationShortcutIcon * iconNewChat =[UIApplicationShortcutIcon iconWithTemplateImageName:@"newChatIcon"];
    UIApplicationShortcutIcon * iconMyQr =[UIApplicationShortcutIcon iconWithTemplateImageName:@"myQRIcon"];
    
    //创建快捷选项
    UIApplicationShortcutItem * itemNewChat =[[UIApplicationShortcutItem alloc] initWithType:@"新建聊天" localizedTitle:@"新建聊天" localizedSubtitle:nil icon:iconNewChat userInfo:nil];
    UIApplicationShortcutItem * itemMyQr =[[UIApplicationShortcutItem alloc] initWithType:@"我的二维码" localizedTitle:@"我的二维码" localizedSubtitle:nil icon:iconMyQr userInfo:nil];
    //添加的快捷选项
    [UIApplication sharedApplication].shortcutItems = @[itemNewChat,itemMyQr];
    
}
- (void)touchStartApp:(UIApplicationShortcutItem *)shortcutItem {
    
    NSString * str = @"";
    if ([shortcutItem.type isEqualToString:@"新建聊天"]) {
        str = @"新建聊天";
    }else if ([shortcutItem.type isEqualToString:@"我的二维码"]){
        str = @"我的二维码";
    }
    
    UIAlertView * ale = [[UIAlertView alloc]initWithTitle:@"提示" message:str delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    [ale show];
}



-(BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<NSString *,id> *)options{
    
    NSLog(@"asdddddddddddddd");
    
    NSString* prefix = @"TodayDemo://";
    if ([[url absoluteString] rangeOfString:prefix].location != NSNotFound) {
        NSString* action = [[url absoluteString] substringFromIndex:prefix.length];
        if ([action isEqualToString:@"GotoHomePage"]) {
            
        }
  
        else if([action isEqualToString:@"GotoOtherPage"]) {
            
        }
    }
    return YES;
}

@end
