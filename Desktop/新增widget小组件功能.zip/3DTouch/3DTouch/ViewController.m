//
//  ViewController.m
//  3DTouch
//
//  Created by Shiwen Huang on 2018/5/8.
//  Copyright © 2018年 Shiwen Huang. All rights reserved.
//

#import "ViewController.h"
#import "DMPresentationViewController.h"

static NSString *reusedId = @"3dTouch";
@interface ViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong)NSArray *arrData;

@property (nonatomic, strong)UITableView *tableView;
@end

@implementation ViewController
#pragma mark - lazy load
- (NSArray *)arrData {
    
    if (!_arrData) {
        
        _arrData = [NSArray array];
        
        NSMutableArray *arr = [NSMutableArray array];
        for (int i = 0; i < 30; i++) {
            
            [arr addObject:@(i)];
        }
        
        _arrData = arr;
    }
    
    return _arrData;
}

- (UITableView *)tableView {
    
    if (!_tableView) {
        
        _tableView = [[UITableView alloc] initWithFrame:self.view.frame style:UITableViewStylePlain];
        _tableView.tableFooterView = [[UIView alloc] init];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [_tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:reusedId];
    }
    
    return _tableView;
}

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    
    [[NSNotificationCenter defaultCenter] addObserver:self.tableView selector:@selector(reloadData) name:@"NOTIFICATION_RELOADDATA" object:nil];
}
- (void)viewWillDisappear:(BOOL)animated {
    
    [[NSNotificationCenter defaultCenter] removeObserver:self.tableView name:@"NOTIFICATION_RELOADDATA" object:nil];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
 
     [self.view addSubview:self.tableView];
 
     [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(touchOrWidgetItem) name:@"touchOrWidgetItem" object:nil];
}

- (void)touchOrWidgetItem{
    [self.navigationController pushViewController:[UIViewController new] animated:YES];
}
#pragma mark - tableView dataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.arrData.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reusedId];
    
    if (!cell) {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reusedId];
    }
    
    cell.contentView.backgroundColor = [UIColor whiteColor];
    
    NSString *str = [NSString stringWithFormat:@"row [%@]", self.arrData[indexPath.row]];
    
    cell.textLabel.text = str;

    
    //注册3D Touch
    //只有在6s及其以上的设备才支持3D Touch,我们可以通过UITraitCollection这个类的UITraitEnvironment协议属性来判断
    /**
     UITraitCollection是UIViewController所遵守的其中一个协议，不仅包含了UI界面环境特征，而且包含了3D Touch的特征描述。
     从iOS9开始，我们可以通过这个类来判断运行程序对应的设备是否支持3D Touch功能。
     UIForceTouchCapabilityUnknown = 0,     //未知
     UIForceTouchCapabilityUnavailable = 1, //不可用
     UIForceTouchCapabilityAvailable = 2    //可用
     */
    if ([self respondsToSelector:@selector(traitCollection)]) {
        
        if ([self.traitCollection respondsToSelector:@selector(forceTouchCapability)]) {
            
            if (self.traitCollection.forceTouchCapability == UIForceTouchCapabilityAvailable) {
                
                [self registerForPreviewingWithDelegate:(id)self sourceView:cell];
            }
        }
    }
    
    return cell;
}
#pragma mark - tableView delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    
    cell.selected = NO;
    
    NSString *str = [NSString stringWithFormat:@"%@", self.arrData[indexPath.row]];
    
    DMPresentationViewController *presentationVC = [[DMPresentationViewController alloc] init];
    presentationVC.strInfo = str;
    
    [self.navigationController pushViewController:presentationVC animated:YES];
}

#pragma mark - UIViewControllerPreviewingDelegate

- (nullable UIViewController *)previewingContext:(id <UIViewControllerPreviewing>)previewingContext viewControllerForLocation:(CGPoint)location NS_AVAILABLE_IOS(9_0) {
    NSIndexPath *indexPath = [self.tableView indexPathForCell:(UITableViewCell *)[previewingContext sourceView]];
    NSString *str = [NSString stringWithFormat:@"%@",self.arrData[indexPath.row]];
    //创建要预览的控制器
    DMPresentationViewController *presentationVC = [[DMPresentationViewController alloc] init];
    presentationVC.arrData = (NSMutableArray *)self.arrData;
    presentationVC.index = indexPath.row;
    presentationVC.strInfo = str;
    
    //指定当前上下文视图Rect
    CGRect rect = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 300);
    previewingContext.sourceRect = rect;
    
    return presentationVC;
}
#pragma mark pop(push)
- (void)previewingContext:(id <UIViewControllerPreviewing>)previewingContext commitViewController:(UIViewController *)viewControllerToCommit NS_AVAILABLE_IOS(9_0) {
    
    [self showViewController:viewControllerToCommit sender:self];
}

@end
